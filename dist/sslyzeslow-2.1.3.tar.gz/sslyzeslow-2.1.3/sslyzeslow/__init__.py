__author__ = "Alban Diquet"
__version__ = "2.1.3"
__email__ = "nabla.c0d3@gmail.com"
PROJECT_URL = "https://github.com/nabla-c0d3/sslyzeslow"
